const {Router} = require("express");

const controller = require("../controllers/tasks.controller");

const router = Router();

router.get("/", controller.findAll);
router.post("/", controller.addTask);
router.delete("/:id", controller.removeTask);
router.get("/review/:id", controller.reviewTask); //checar por id 
router.push("/:id", controller.updateTitle); //actualizar el titulo

module.exports = router;