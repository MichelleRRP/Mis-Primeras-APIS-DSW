const Task = require('../models/task.model');

exports.findAll =(req, res) => {
    const data = Task.findAll();
    res.status(200).json(data);
}

exports.addTask = (req,res) => {
    const title = req.body.title;
    const createdTask = Task.create(title);
    res.status(201).json(createdTask);
}

exports.removeTask = (req,res) => {
    const id = req.params.id;
    const ok = Task.removeTask(id);

    if(!ok){
        return res.status(404).json({message: 'Tarea no encontrada'});
    }

     res.status(204).json({message: 'Tarea eliminada'})
}

//consultar

exports.reviewTask = (req,res) => {
   const id = req.params.id; //sacamos el id 
   const title = req.params.title; //sacamos el titulo
   const completed = req.params.completed; //sacamos si está completado o no
   res.status(200).json(data); //codigo de encontrado
}

//cambiar titulo

exports.updateTitle = (req, res) => {
     const id = req.params.id; //sacamos el id 
     const newTitle = req.params.newTitle;
     const updatedTask = Task.update(newTitle); //como singaos actualizo el titulooo

}

//cambiar estado completed

exports.updateCompleted = (req, res) => {
     const id = req.params.id; //sacamos el id 
     const newTitle = req.params.newTitle;
     const updatedTask = Task.update(newTitle); //como singaos actualizo el completeddd
}