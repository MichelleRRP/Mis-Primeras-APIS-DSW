const {randomUUID} = require("node:crypto");

let tasks = [
    {id:randomUUID(), title:"Aprender API Rest", completed:false },
   {id:randomUUID(), title:"Aprender API Rest", completed:false },

];

function findAll(){
    return tasks;
}

function addTask(title){
    const task= {
        id: randomUUID(),
        title: title,
        completed: false
    }

    tasks.push(task);
    return task;
}

function removeTask(id){
    const index = tasks.findIndex(item=> item.id===id);

    if (index===1){
        return false;
    }

    tasks.splice(index,1);
    return true;
}

//consultar tarea
function reviewTask(id){
    const index = tasks.findIndex(item => item.id===id); //aqui encontramos la tarea por el id

    if (index ===1){ //no se encontró la tarea
        return false;
    }

    //maybe ponerle que muestre las cosas

}


//actualizar el título
function updateTitle(id, newTitle){
    const index = tasks.findIndex(item => item.id===id); //aqui encontramos la tarea por el id

    //NO SE QUE MAS PONERLE AHHHH

}


//completar/descompletar una tarea
function updateCompleted(id, state){
    const index = tasks.findIndex(item => item.id===id); //aqui encontramos la tarea por el id
    //debe de poder actualizarse de la misma manera que el titulo
    //este es un booleano true pr false

}

module.exports = {findAll, addTask, removeTask};

//modelo, controlador y ruta, si es necesario modificar el app lo haces pues
//consultar tarea por identificador, actualizar el titulo de una tarea y completar/descompletar una tarea

//path param   req.param.id

//body param   suele ser un JSON
